# Camp Snow 0.3.17 stereo BGM resource pack

dist/campsnow.zip is the playable resource pack. The source archive is not a playable pack.
The reference folder contains the hash-verified 0.3.16 client pack; assets contains the original stereo tracks.
build_pack.py rebuilds only the three BGM sounds, their definitions and the pack description.
It expects ffmpeg.exe and ffprobe.exe at ../ResourcePack-Wind-v0.3.12/tools/; adjust these paths for another machine.
All other assets are checked byte-identical. Decode/format/archive checks passed; live client listening is pending.
