from pathlib import Path
import copy, json, hashlib, zipfile, subprocess

r = Path(__file__).resolve().parent
root = r.parent
r.mkdir(exist_ok=True)
for name in ['reference', 'assets', 'evidence', 'dist']:
    (r / name).mkdir(exist_ok=True)
base = r / 'reference/baseline-campsnow-0.3.16.zip'
assert hashlib.sha1(base.read_bytes()).hexdigest() == '0fde6c694649bf640f556e57e79466c534b54e88'
backup = r / 'reference/baseline-campsnow-0.3.16.zip'
backup.write_bytes(base.read_bytes())
ff = root / 'ResourcePack-Wind-v0.3.12/tools/ffmpeg.exe'
fp = ff.with_name('ffprobe.exe')
previous = json.loads((r / 'assets/stereo-reference.json').read_text(encoding='utf-8'))
tracks = []
with zipfile.ZipFile(base) as old:
    assert old.testzip() is None and 'pack.mcmeta' in old.namelist()
    manifest = json.loads(old.read('assets/campsnow/sounds.json'))
    original_manifest = copy.deepcopy(manifest)
    meta = json.loads(old.read('pack.mcmeta'))
    meta['pack']['description'] = 'Camp Snow v0.3.17 | Stereo Cabin BGM'
    replacement = {'pack.mcmeta': json.dumps(meta, ensure_ascii=False, indent=2).encode()}
    for i, prior in enumerate(previous, 1):
        src = r / f'assets/winter_cabin{i}.ogg'
        data = src.read_bytes()
        assert hashlib.sha256(data).hexdigest() == prior['ogg_sha256'], 'Original stereo track changed'
        assert prior['probe']['streams'][0]['channels'] == 2
        audio = r / f'assets/winter_cabin{i}.ogg'
        audio.write_bytes(data)
        probe_run = subprocess.run(list(map(str, [fp, '-v', 'error', '-show_entries', 'stream=channels,codec_name,sample_rate:format=duration', '-of', 'json', audio])), capture_output=True, check=True)
        probe = json.loads(probe_run.stdout)
        assert probe['streams'][0]['channels'] == 2 and probe['streams'][0]['codec_name'] == 'vorbis'
        assert abs(float(probe['format']['duration']) - prior['duration_seconds']) < .01
        decode = subprocess.run(list(map(str, [ff, '-v', 'error', '-i', audio, '-f', 'null', '-'])), capture_output=True)
        (r / f'evidence/decode-{i}.log').write_bytes(decode.stderr)
        decode.check_returncode()
        replacement[f'assets/campsnow/sounds/bgm/winter_cabin{i}.ogg'] = data
        manifest[f'bgm.winter_cabin{i}'] = {'sounds': [{'name': f'campsnow:bgm/winter_cabin{i}', 'stream': True}]}
        tracks.append({'id': prior['id'], 'sha256': prior['ogg_sha256'], 'probe': probe, 'fade_in_seconds': 2, 'fade_out_seconds': 3, 'reuses_original_stereo_ogg': True})
    replacement['assets/campsnow/sounds.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode()
    out = r / 'dist/campsnow.zip'
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for info in old.infolist():
            z.writestr(copy.copy(info), replacement.get(info.filename, old.read(info.filename)))
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
        assert set(z.namelist()) == set(old.namelist())
        changed = sorted(n for n in old.namelist() if old.read(n) != z.read(n))
        assert set(changed) == set(replacement)
        assert all(manifest[k] == v for k, v in original_manifest.items() if not k.startswith('bgm.'))
        assert len(manifest) == len(original_manifest)
        assert 'pack.mcmeta' in z.namelist() and 'assets/campsnow/sounds.json' in z.namelist(), 'Must be a playable pack, not a source bundle'
    report = {'version': '0.3.17', 'baseline_sha1': hashlib.sha1(base.read_bytes()).hexdigest(), 'sha1': hashlib.sha1(out.read_bytes()).hexdigest(), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(), 'bytes': out.stat().st_size, 'changed_entries': changed, 'all_other_assets': 'BYTE IDENTICAL including wind, wood GUIs, temperature bar and other sounds', 'tracks': tracks, 'CRC': 'PASS', 'duplicates': False, 'full_ogg_decode': 'PASS', 'live_files': 'NOT MODIFIED', 'client_audio_QA': 'NOT PERFORMED'}
    (r / 'dist/verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    (r / 'dist/resource-pack-sha1.txt').write_text(report['sha1'] + '\n', encoding='utf-8')
    print(json.dumps({'PACK SHA1': report['sha1'], 'bytes': report['bytes'], 'channels': 2, 'all_other_assets': report['all_other_assets']}, ensure_ascii=False))
