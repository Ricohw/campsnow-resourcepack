from pathlib import Path
import zipfile,json,hashlib,subprocess,copy
r=Path('ResourcePack-BGM-v0.3.16');base=Path('ResourcePack-BGM-v0.3.15/dist/campsnow.zip');assert hashlib.sha1(base.read_bytes()).hexdigest()=='f4a0a70f0b9901751397280545311a0796e9456c';(r/'reference/baseline-campsnow.zip').write_bytes(base.read_bytes())
ff=Path('ResourcePack-Wind-v0.3.12/tools/ffmpeg.exe');fp=ff.with_name('ffprobe.exe');tracks=[]
with zipfile.ZipFile(base) as old:
 manifest=json.loads(old.read('assets/campsnow/sounds.json'));meta=json.loads(old.read('pack.mcmeta'));meta['pack']['description']='Camp Snow v0.3.16 | Cabin BGM Distance Fade'
 repl={'pack.mcmeta':json.dumps(meta,ensure_ascii=False,indent=2).encode()}
 for i in range(1,4):
  src=Path('C:/Users/누리킹/Downloads')/f'Winter Cabin{i}.mp3';out=r/f'assets/winter_cabin{i}.ogg'
  def run(cmd):
   p=subprocess.run(list(map(str,cmd)),capture_output=True);p.check_returncode();return p.stdout
  duration=float(json.loads(run([fp,'-v','error','-show_entries','format=duration','-of','json',src]))['format']['duration'])
  run([ff,'-v','error','-y','-i',src,'-vn','-ac','1','-af',f'afade=t=in:st=0:d=2,afade=t=out:st={duration-3}:d=3','-c:a','libvorbis','-q:a','5',out]);run([ff,'-v','error','-i',out,'-f','null','-'])
  probe=json.loads(run([fp,'-v','error','-show_entries','stream=channels,codec_name:format=duration','-of','json',out]));assert probe['streams'][0]['channels']==1 and probe['streams'][0]['codec_name']=='vorbis';assert abs(float(probe['format']['duration'])-duration)<.2
  name=f'assets/campsnow/sounds/bgm/winter_cabin{i}.ogg';repl[name]=out.read_bytes();manifest[f'bgm.winter_cabin{i}']['sounds'][0]['attenuation_distance']=16;tracks.append({'source':src.name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'ogg_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'probe':probe})
 repl['assets/campsnow/sounds.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
 out=r/'dist/campsnow.zip'
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for info in old.infolist():z.writestr(copy.copy(info),repl.get(info.filename,old.read(info.filename)))
 with zipfile.ZipFile(out) as z:
  assert z.testzip() is None and len(z.namelist())==len(set(z.namelist())) and set(old.namelist())==set(z.namelist());changed=[n for n in old.namelist() if old.read(n)!=z.read(n)];assert set(changed)==set(repl)
  original=json.loads(old.read('assets/campsnow/sounds.json'));assert all(manifest[k]==v for k,v in original.items() if not k.startswith('bgm.'))
 report={'version':'0.3.16','sha1':hashlib.sha1(out.read_bytes()).hexdigest(),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'changed_entries':changed,'tracks':tracks,'CRC':'PASS','full_ogg_decode':'PASS','fade_in_seconds':2,'fade_out_seconds':3,'channels':1,'attenuation_distance':16,'all_other_assets':'BYTE IDENTICAL','live_files':'NOT MODIFIED','client_audio_QA':'NOT PERFORMED'}
 (r/'dist/verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');(r/'dist/resource-pack-sha1.txt').write_text(report['sha1']+'\n');print('PACK SHA1',report['sha1'])
mc=Path('C:/Users/누리킹/AppData/Roaming/.minecraft');v=json.loads((mc/'versions/26.3/26.3.json').read_text());idx=json.loads((mc/'assets/indexes'/f"{v['assetIndex']['id']}.json").read_text());h=idx['objects']['minecraft/sounds.json']['hash'];vanilla=json.loads((mc/'assets/objects'/h[:2]/h).read_text())
keys=sorted('minecraft:'+k for k in vanilla if k.startswith('music.'))
Path('CampCore-0.3.86-work/source-patch/examples/bgm-vanilla-music.txt').write_text('\n'.join(keys)+'\n',encoding='utf-8');print('Vanilla music events',len(keys))
