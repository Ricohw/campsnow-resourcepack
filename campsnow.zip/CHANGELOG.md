# Camp Snow Resource Pack v0.3

## Added
- Ice-metal hotbar family (`hotbar`, selected slot, offhand).
- Cozy wooden-camp survival inventory background.
- Cozy creative-inventory backgrounds plus modern creative tab/scroller sprites.
- Cozy recipe-book background plus recipe-book buttons/tabs/page/filter/slot sprites.

## Preserved
- Temperature XP bar HUD from v0.2.2.
- Ice slime entity texture.
- Ice slimeball item texture.
- Clear ice-jelly slime-block texture.
- Vanilla font/numerals.

## QA
- Verify survival inventory alignment.
- Verify creative top/bottom tabs, scroller and search screen.
- Verify recipe-book open state and recipe buttons.
- Verify hotbar selection/offhand placement.


## v0.3.2
- Fixed inventory GUI corruption caused by stray pixels outside the intended canvas.
- Removed irregular bright studs/dots from the top of the wooden borders on inventory/recipe UI.
- Kept the purple-brown wooden frame while simplifying the top edge for a cleaner look.
- Preserved existing temperature HUD and slime-themed assets.

## v0.3.3
- Raised the luminance of hotbar and item-slot interiors for clearer item readability.
- Removed bright streaks and stray frost pixels from creative inventory backgrounds.
- Removed the thick pale pedestal under the survival inventory player preview.
- Shifted creative item/search slot artwork by one pixel to better center item icons.
- Simplified the creative survival-tab interior so Minecraft 26.3 dynamic equipment elements do not collide with static artwork.
- Preserved the temperature HUD, ice slime, slimeball, slime block, recipe book, and wood-camp frame family.

## v0.3.4
- Rebuilt the creative survival-tab slot map from an actual Minecraft 26.3 screenshot.
- Restored the player preview, five equipment/off-hand slots, 3x9 inventory, and 9-slot hotbar.
- Replaced the remaining pale creative-inventory inner perimeter with a warm wood highlight.
- Preserved all v0.3.3 HUD, slime, recipe-book, and inventory assets.
