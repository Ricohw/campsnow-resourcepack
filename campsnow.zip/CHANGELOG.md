# Camp Snow Resource Pack v0.3

## Added
- Ice-metal hotbar family (`hotbar`, selected slot, offhand).
- Cozy wooden-camp survival inventory background.
- Cozy creative-inventory backgrounds plus modern creative tab/scroller sprites.
- Cozy recipe-book background plus recipe-book buttons/tabs/page/filter/slot sprites.

## Preserved
- Temperature XP bar HUD from v0.2.2.
- Ice slime entity texture.
- Ice slimeball item texture.
- Clear ice-jelly slime-block texture.
- Vanilla font/numerals.

## QA
- Verify survival inventory alignment.
- Verify creative top/bottom tabs, scroller and search screen.
- Verify recipe-book open state and recipe buttons.
- Verify hotbar selection/offhand placement.


## v0.3.2
- Fixed inventory GUI corruption caused by stray pixels outside the intended canvas.
- Removed irregular bright studs/dots from the top of the wooden borders on inventory/recipe UI.
- Kept the purple-brown wooden frame while simplifying the top edge for a cleaner look.
- Preserved existing temperature HUD and slime-themed assets.

## v0.3.3
- Raised the luminance of hotbar and item-slot interiors for clearer item readability.
- Removed bright streaks and stray frost pixels from creative inventory backgrounds.
- Removed the thick pale pedestal under the survival inventory player preview.
- Shifted creative item/search slot artwork by one pixel to better center item icons.
- Simplified the creative survival-tab interior so Minecraft 26.3 dynamic equipment elements do not collide with static artwork.
- Preserved the temperature HUD, ice slime, slimeball, slime block, recipe book, and wood-camp frame family.

## v0.3.4
- Rebuilt the creative survival-tab slot map from an actual Minecraft 26.3 screenshot.
- Restored the player preview, five equipment/off-hand slots, 3x9 inventory, and 9-slot hotbar.
- Replaced the remaining pale creative-inventory inner perimeter with a warm wood highlight.
- Preserved all v0.3.3 HUD, slime, recipe-book, and inventory assets.

## v0.3.5
- Warm greige inventory slot interiors, preserving slot geometry.
- Subtle paper grain and a higher paper backdrop behind the fixed crafting label.
- Native 24x24 hover sprites with transparent margins; visible frame limited to 18x18.
- Lower hover fill opacity and transparent foreground centers for item readability.
- Preserved other HUD, slime, recipe-book and creative-tab assets.

## v0.3.6
- Reverted the raised paper backdrop; restored the original wooden top frame.
- Separated the character-window outline and offhand frame with two paper pixels.
- Aligned the offhand artwork to the actual 26.3 icon origin (77,62).
- Preserved all other v0.3.5 assets and hover behavior.

## v0.3.7
- Aligned the crafting-result frame to the client item origin (154,28).
- Shifted the straight right frame inner edge by two pixels; kept outer frame pixels unchanged.
- Added a one-pixel paper gap between the result slot and right wooden frame.
- Preserved all other v0.3.6 assets and client slot/entity coordinates.

## v0.3.8
- Unified survival-inventory outer wood-frame thickness to four native pixels on every side.
- Kept all slot, character/offhand and crafting-result artwork positions unchanged.
- Preserved previous hover, color and spacing corrections and all other resources.
